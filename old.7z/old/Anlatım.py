constInfo.py ye Ekleyın

SCHICKSAL_RAD = {
					"index" : 0,
					"ServerCMD" : "",
					"kosten" : 0,
					"free" : 0
}

Game py Açın ve Importlara Ekleyın

import schicksalrad


Aratın

def __init__(self, stream):

En Altına Ekleyın


self.SchicksalRad = schicksalrad.RadDesSchicksals()


Aratın

def Close(self):

En Altına Ekleyın

		if self.SchicksalRad.IsShow():
			self.SchicksalRad.Open()


Aratın

def __ServerCommand_Build(self):

Ekleyın			
			
			"SCHICKSAL_RAD"				: self.__SchicksalRad,
			"SCHICKSAL_RAD_OPEN"				: self.__SchicksalRadOpen,


En Alta Ekleyın			
			
	def __SchicksalRad(self, cmd):
		CMD =  cmd.split("/")
		if CMD[0]=="index":
			constInfo.SCHICKSAL_RAD["index"] = int(CMD[1])
			constInfo.SCHICKSAL_RAD["kosten"] = int(CMD[2])
			constInfo.SCHICKSAL_RAD["free"] = int(CMD[3])
		elif CMD[0]=="input":
			net.SendQuestInputStringPacket(str(constInfo.SCHICKSAL_RAD["ServerCMD"]))
		elif CMD[0]=="free":
			constInfo.SCHICKSAL_RAD["free"] = int(CMD[1])
		elif CMD[0]=="Answer":
			self.SchicksalRad.SetVars(CMD[1], CMD[2], CMD[3], CMD[4], CMD[5])
			constInfo.SCHICKSAL_RAD["free"] = int(CMD[6])

	def __SchicksalRadOpen(self):
		self.SchicksalRad.Open()			