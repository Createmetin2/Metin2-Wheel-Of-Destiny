import ui
import dbg
import app
import player
import chat
import chr
import item
import constInfo
import event
import uiToolTip

class RadDesSchicksals(ui.Window):
	def __init__(self):
		ui.Window.__init__(self)
		self.Hide()
		self.tooltipItem = uiToolTip.ItemToolTip()
		self.tooltipItem.Hide()
		self.itemfortip = 0
		self.Price = None
		self.Start = 0
		self.Counter = 0
		self.Langsamer = 0
		self.Grad = 0
		self.Item = 0
		self.Random = 0
		self.GradZaehler = 0
		self.Loaded = 0
		self.ItemPosis = [ 
						{"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30}, {"32":10, "64":20,"96":30} ]

	def BuildWindow(self):
		if self.Loaded>0:
			self.Board.Show()
			self.Show()
			return

		self.Loaded = 1
		self.Board = ui.ExpandedImageBox()
		self.Board.AddFlag("movable")
		self.Board.AddFlag("float")
		self.Board.LoadImage("schicksal/schicksal_board.tga")
		self.Board.SetCenterPosition()
		self.Board.Show()

		self.Wheel = ui.ExpandedImageBox()
		self.Wheel.SetParent(self.Board)
		self.Wheel.LoadImage("schicksal/schicksal_rad.tga")
		self.Wheel.SetPosition(15,45)
		self.Wheel.AddFlag("not_pick")
		self.Wheel.Show()

		self.CloseButton = ui.Button()
		self.CloseButton.SetParent(self.Board)
		self.CloseButton.SetEvent(self.Open)
		self.CloseButton.SetPosition(605, 45)
		self.CloseButton.SetUpVisual("d:/ymir work/ui/public/close_button_01.sub")
		self.CloseButton.SetOverVisual("d:/ymir work/ui/public/close_button_02.sub")
		self.CloseButton.SetDownVisual("d:/ymir work/ui/public/close_button_03.sub")
		self.CloseButton.Show()

		self.SlotBg = ui.ExpandedImageBox()
		self.SlotBg.SetParent(self.Board)
		self.SlotBg.SetPosition(553, 127)
		self.SlotBg.LoadImage("schicksal/slot.tga")
		self.SlotBg.AddFlag("not_pick")
		self.SlotBg.Show()

		self.Button = ui.Button()
		self.Button.SetParent(self.Wheel)
		self.Button.SetUpVisual("schicksal/schicksal_drehen_normal.tga")
		self.Button.SetOverVisual("schicksal/schicksal_drehen_over.tga")
		self.Button.SetDownVisual("schicksal/schicksal_drehen_down.tga")
		self.Button.SetPosition(177, 181)
		self.Button.SetEvent(self.__CanSpin)
		self.Button.Show()
		self.Yang = ui.TextLine()
		self.Yang.SetParent(self.Board)
		self.Yang.SetPosition(57, 576)
		self.Yang.SetFontColor(0.5, 1.0, 0.5)
		self.Yang.SetFontName("Arial:16")
		self.Yang.SetText("9.999.999.999 Yang")
		self.Yang.Show()
		self.FreeSpin = ui.TextLine()
		self.FreeSpin.SetParent(self.Board)
		self.FreeSpin.SetPosition(450, 574)
		self.FreeSpin.SetFontColor(0.5, 1.0, 0.5)
		self.FreeSpin.SetFontName("Arial:20")
		self.FreeSpin.SetText("1")
		self.FreeSpin.Show()

		self.__Fragis()

		self.Show()

	def __Fragis(self):
		self.GUI = []
		self.ItemPosis = [ 
						{"32":387, "64":377,"96":362}, {"32":427, "64":412,"96":392}, {"32":437, "64":427,"96":397}, {"32":423, "64":413,"96":383}, {"32":389, "64":369,"96":349}, {"32":320, "64":308,"96":288}, {"32":240, "64":228,"96":208}, {"32":167, "64":147,"96":127}, {"32":99, "64":79,"96":62}, {"32":52, "64":32,"96":12}, {"32":35, "64":20,"96":0}, {"32":56, "64":36,"96":26}, {"32":100, "64":85,"96":65}, {"32":170, "64":153,"96":133}, {"32":247, "64":227,"96":207}, {"32":330, "64":310,"96":295} ]
		self.Positionen = [ [383, 383, 320], [320, 422, 340], [245, 437, 0], [167, 423, 25], [100, 379, 50], [58, 318, 65],
					[40, 238, 90], [54, 157, 115], [97, 89, 140], [166, 42, 160], [245, 25, 180],
					[331, 46, 210], [394, 95, 232], [433, 163, 253], [445, 237, 272], [425, 320, 300] ]

		for i in xrange(len(self.Positionen)):
			IconImage = ui.ExpandedImageBox()
			IconImage.SetParent(self.Wheel)
			IconImage.SetPosition(self.Positionen[i][0], self.Positionen[i][1])
			IconImage.LoadImage("schicksal/schicksal_fragi.tga")
			IconImage.SetRotation(self.Positionen[i][2])
			IconImage.AddFlag("not_pick")
			IconImage.Show()
			self.GUI.append(IconImage)

	def __None(self):
		pass

	def SetVars(self, Answer, Grad, Spin, ItemId, Random):
		if Answer=="1":
			self.Langsamer = 10
			self.Item = int(ItemId)
			self.Counter = int(Spin)
			self.GradZaehler = 0
			self.Grad = int(Grad)
			self.Random = int(Random)-1
			self.Start = 1
			#chat.AppendChat(1, str(self.Grad) +" "+ str(self.Counter))
		else:
			self.Button.SetEvent(self.__CanSpin)
			self.Start = 0

	def __CanSpin(self):
		self.Button.SetEvent(self.__None)
		self.__Fragis()
		constInfo.SCHICKSAL_RAD["ServerCMD"] = "-1"
		event.QuestButtonClick(constInfo.SCHICKSAL_RAD["index"])

	def __BuildLastItem(self, path):
		self.Price = ui.ExpandedImageBox()
		self.Price.SetParent(self.SlotBg)
		self.Price.SetPosition(0, 0)
		self.Price.LoadImage(path)
		self.Price.Show()

	def OnUpdate(self):
		# Update Text Start
		if (self.Yang.GetText())!=(self.NumberToMoneyString(player.GetElk()) + " Yang"):
			self.Yang.SetText(self.NumberToMoneyString(constInfo.SCHICKSAL_RAD["kosten"]) + " Yang")
		if int(self.FreeSpin.GetText())!=constInfo.SCHICKSAL_RAD["free"]:
			self.FreeSpin.SetText(str(constInfo.SCHICKSAL_RAD["free"]))
		# Update Text End
		#Tooltip Start
		if self.Price:
			if self.Price.IsIn():
				self.tooltipItem.SetItemToolTip(self.itemfortip)
			else:
				self.tooltipItem.HideToolTip()
		#ToolTip End
		#Drehen Start
		if self.Start==1:
			if self.Counter==0:
				if self.Langsamer>0:
					self.Langsamer = self.Langsamer - 0.1
					self.Grad = self.Grad + self.Langsamer
				else:
					item.SelectItem(self.Item)
					itemIcon = item.GetIconImageFileName()
					#chat.AppendChat(1, str(itemIcon))
					self.GUI[self.Random].LoadImage(itemIcon)
					try:
						s = str(self.GUI[self.Random].GetHeight())
						self.GUI[self.Random].SetPosition(self.Positionen[self.Random][0], self.ItemPosis[self.Random][s])
					except KeyError:
						chat.AppendChat(1, "Reporting to the server, the Item size does not exist.")
					constInfo.SCHICKSAL_RAD["ServerCMD"] = "-2"
					event.QuestButtonClick(constInfo.SCHICKSAL_RAD["index"])
					self.itemfortip = self.Item
					self.__BuildLastItem(itemIcon)
					#chat.AppendChat(1, "Fertig")
					self.Start = 0
					self.Button.SetEvent(self.__CanSpin)
			else:
				self.Grad = self.Grad + self.Langsamer
				self.GradZaehler = self.GradZaehler + self.Langsamer
				if self.GradZaehler>=360:
					self.GradZaehler = 0
					if self.Counter>0:
						self.Counter = self.Counter -1
			self.Wheel.SetRotation(self.Grad)
		# Drehen End

	def NumberToMoneyString(self, money):
		sourceText = str(money) 
		if len(sourceText) <= 3:
			return sourceText  
		return self.NumberToMoneyString(sourceText[:-3]) + "." + sourceText[-3:]

	def Open(self):
		if self.IsShow():
			self.Board.Hide()
			self.Hide()
			return
		self.BuildWindow()

